import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from radar.business_graph import BusinessModelError, build_business_graph, validate_business_model
from radar.model import load_pack
from radar.discover import run_discovery

class TestBusinessGraph(unittest.TestCase):
    def _data(self):
        root = Path(__file__).resolve().parents[1]
        pack = load_pack(root / "packs/weak-current/pack.json")
        model = json.loads((root / "packs/weak-current/business-model.json").read_text(encoding="utf-8"))
        return root, pack, model

    def test_weak_current_business_model_is_valid(self):
        _, pack, model = self._data()
        self.assertEqual(validate_business_model(model, pack)["pack"], "weak-current")
        self.assertEqual(len(model["entities"]), 7)
        self.assertEqual(len(model["exceptions"]), 6)
        self.assertEqual(len(model["ledger_aggregations"]), 3)
        self.assertEqual({item["ledger_kind"] for item in model["ledger_aggregations"]},
                         {"stock", "general_ledger"})

    def test_pack_business_model_can_declare_explicit_ledger_source_adapter(self):
        _, pack, model = self._data()
        adapter = {
            "id": "erp-stock-csv-v1", "source_system": "erp-a",
            "format": "csv", "ledger_kind": "stock", "header_row": 1,
            "delimiter": ",",
            "field_map": {
                "ledger_entry_id": "Ledger Entry ID",
                "company_id": "Company ID",
                "voucher_type": "Voucher Type",
                "voucher_id": "Voucher ID",
                "voucher_item_id": "Voucher Item ID",
                "event_kind": "Event Kind",
                "posting_status": "Posting Status",
                "currency": "Currency",
                "accounting_period": "Accounting Period",
                "item_id": "Item ID", "warehouse_id": "Warehouse ID",
                "quantity_delta": "Quantity Delta", "quantity_uom": "Quantity UOM",
                "stock_value_delta": "Stock Value Delta",
            },
            "number_format": {"decimal_separator": ".", "thousands_separator": ","},
        }
        model["ledger_source_adapters"] = [adapter]
        validated = validate_business_model(model, pack)
        self.assertEqual(validated["ledger_source_adapters"][0]["id"], "erp-stock-csv-v1")
        model["ledger_source_adapters"] = [adapter, dict(adapter)]
        with self.assertRaises(BusinessModelError):
            validate_business_model(model, pack)

    def test_unknown_transition_endpoint_is_rejected(self):
        _, pack, model = self._data()
        model["processes"][0]["transitions"][0]["to"] = "missing_entity"
        with self.assertRaises(BusinessModelError):
            validate_business_model(model, pack)

    def test_term_match_is_candidate_only_and_provenance_is_retained(self):
        _, pack, model = self._data()
        assets = [{"id":"ast_file_1","title":"purchase_receipt.py","asset_type":"file",
                   "uri":"https://example.test/purchase_receipt.py","version_ref":"abc"}]
        evidence = [{"id":"evd_receipt_1","asset_id":"ast_file_1","evidence_kind":"code",
                     "statement":"purchase receipt validates rejected_qty and accepted_qty",
                     "excerpt":"quality inspection","locator":{"path":"purchase_receipt.py","line_start":20},
                     "verification_status":"source_confirmed"}]
        graph = build_business_graph(model, pack, assets=assets, evidence=evidence)
        matches = [e for e in graph["edges"] if e["relation"] == "candidate_mention"]
        self.assertTrue(matches)
        self.assertTrue(all(e["status"] == "candidate_only" for e in matches))
        self.assertTrue(all(e["evidence_ids"] == ["evd_receipt_1"] for e in matches))
        self.assertTrue(all(e["provenance"]["locator"]["path"] == "purchase_receipt.py" for e in matches))
        self.assertFalse(any(e["relation"] in ("implements", "supports") for e in graph["edges"]))

    def test_declared_transitions_are_not_claimed_as_verified(self):
        _, pack, model = self._data()
        graph = build_business_graph(model, pack)
        declared = [e for e in graph["edges"] if e["relation"] == "declared_transition"]
        self.assertTrue(declared)
        self.assertTrue(all(e["status"] == "declared_not_verified" for e in declared))
        self.assertTrue(all(not e["evidence_ids"] for e in declared))

    def test_process_steps_and_criterion_entity_links_are_explicit_candidates(self):
        _, pack, model = self._data()
        requirement = {"id":"req_d03","key":"D03","version":1,"title":"材料采购",
            "acceptance_criteria":[{"id":"D03-C5","description":"采购收货逐行关联采购订单，支持分批收货。","required":True}]}
        graph = build_business_graph(model, pack, requirements=[requirement])
        self.assertTrue(any(e["relation"] == "has_step" for e in graph["edges"]))
        candidates = [e for e in graph["edges"] if e["relation"] == "candidate_requires"]
        self.assertTrue(candidates)
        self.assertTrue(all(e["status"] == "candidate_only" for e in candidates))

    def test_business_graph_cli_reads_workspace_and_writes_projection(self):
        root, pack, model = self._data()
        with tempfile.TemporaryDirectory() as tmp:
            workspace_root = Path(tmp) / "store"
            pack_path = root / "packs/weak-current/pack.json"
            run_discovery("ws_business_graph_cli", str(root / "examples/requirements/d03-material-procurement.json"),
                str(pack_path), str(root / "seeds/weak-current.json"), str(workspace_root))
            output = Path(tmp) / "business-graph.json"
            observations_path = Path(tmp) / "observations.json"
            observations_path.write_text(json.dumps({"schema_version":1,"observations":[]}),
                                         encoding="utf-8")
            proc = subprocess.run([sys.executable, "-m", "radar", "business-graph",
                "--workspace", "ws_business_graph_cli", "--workspace-root", str(workspace_root),
                "--pack", str(pack_path), "--business-model", str(root / "packs/weak-current/business-model.json"),
                "--observations", str(observations_path), "--out", str(output)],
                cwd=str(root), capture_output=True, text=True, timeout=30)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            graph = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(graph["counts"]["entities"], 7)
            self.assertEqual(graph["counts"]["evidence"], 0)
            self.assertEqual(graph["counts"]["candidate_entity_mentions"], 0)
            self.assertEqual(graph["counts"]["criteria_no_evidence"], 11)
            self.assertEqual(graph["counts"]["criterion_candidate_evidence_links"], 0)
            self.assertEqual(graph["counts"]["invariant_evaluations"], 0)
            self.assertEqual(graph["counts"]["invariants_without_observations"], 6)
            self.assertEqual(graph["counts"]["criteria_with_invariant_mappings"], 6)
            self.assertEqual(graph["workspace_id"], "ws_business_graph_cli")
            self.assertTrue(all(item["invariant_status"] == "no_observation"
                                for item in graph["criterion_evidence_matrix"] if item["invariant_ids"]))
            self.assertEqual(len(graph["discovery_run_ids"]), 1)
            self.assertEqual(len([n for n in graph["nodes"] if n["kind"] == "acceptance_criterion"]), 11)

    def test_criterion_evidence_matrix_and_cross_file_transition_are_candidates(self):
        _, pack, model = self._data()
        requirement = {"id":"req_d03","key":"D03","version":1,"title":"材料采购",
            "acceptance_criteria":[{"id":"D03-C5","description":"采购收货关联采购订单，支持分批收货。","required":True}]}
        assets = [{"id":"ast_order","title":"order.py","asset_type":"file","uri":"https://x/order.py"},
                  {"id":"ast_receipt","title":"receipt.py","asset_type":"file","uri":"https://x/receipt.py"}]
        evidence = [
            {"id":"evd_order","asset_id":"ast_order","statement":"purchase order item qty",
             "excerpt":"Purchase Order","locator":{"path":"order.py","line_start":20},"verification_status":"unverified"},
            {"id":"evd_receipt","asset_id":"ast_receipt","statement":"purchase receipt received_qty accepted_qty",
             "excerpt":"Purchase Receipt","locator":{"path":"receipt.py","line_start":10},"verification_status":"source_confirmed"}]
        relationships = [{"id":"rel_cross","from":{"object_type":"asset","id":"ast_order"},
            "to":{"object_type":"asset","id":"ast_receipt"},"relation_type":"depends_on","status":"active",
            "evidence_ids":["evd_order","evd_receipt"]}]
        graph = build_business_graph(model, pack, requirements=[requirement],
            assets=assets, evidence=evidence, relationships=relationships)
        matrix = graph["criterion_evidence_matrix"][0]
        self.assertEqual(matrix["status"], "candidate_evidence")
        self.assertEqual(set(matrix["candidate_evidence_ids"]), {"evd_order", "evd_receipt"})
        candidate_edges = [e for e in graph["edges"] if e["relation"] == "candidate_evidence_for"]
        self.assertEqual(len(candidate_edges), 2)
        self.assertTrue(all(e["status"] == "candidate_only" for e in candidate_edges))
        transition_edges = [e for e in graph["edges"] if e["relation"] == "candidate_transition"]
        self.assertTrue(transition_edges)
        self.assertEqual(set(transition_edges[0]["evidence_ids"]), {"evd_order", "evd_receipt"})
        self.assertFalse(any(e["relation"] in ("implements", "supports") for e in graph["edges"]))

    def test_criterion_without_matching_evidence_is_explicit_no_evidence(self):
        _, pack, model = self._data()
        requirement = {"id":"req_d03","key":"D03","version":1,"title":"材料采购",
            "acceptance_criteria":[{"id":"D03-C10","description":"库存价值与总账一致。","required":True}]}
        graph = build_business_graph(model, pack, requirements=[requirement])
        matrix = graph["criterion_evidence_matrix"][0]
        self.assertEqual(matrix["status"], "no_evidence")
        self.assertEqual(matrix["candidate_evidence_ids"], [])

    def test_code_state_transition_is_exposed_as_unverified_candidate(self):
        _, pack, model = self._data()
        evidence = [{"id":"evd_state","asset_id":"ast_code","statement":"Draft -> Submitted",
            "locator":{"path":"receipt.py","line_start":4,"line_end":5},
            "metadata":{"code_analysis":{"kind":"state_transition_candidate",
                "from_state":"Draft","to_state":"Submitted","scope":["function:submit"],
                "inference_status":"candidate_only"}}}]
        graph = build_business_graph(model, pack,
            assets=[{"id":"ast_code","title":"receipt.py","asset_type":"file","uri":"https://x/receipt.py"}],
            evidence=evidence)
        state_nodes = [n for n in graph["nodes"] if n["kind"] == "code_state_transition"]
        self.assertEqual(len(state_nodes), 1)
        self.assertEqual(state_nodes[0]["from_state"], "Draft")
        self.assertEqual(state_nodes[0]["to_state"], "Submitted")
        self.assertEqual(state_nodes[0]["inference_status"], "candidate_only")
        self.assertEqual(graph["counts"]["candidate_code_state_transitions"], 1)

    def test_pack_invariants_are_declared_not_evaluated(self):
        _, pack, model = self._data()
        model["invariants"] = [{
            "id":"qty_balance","name":"Quantity balance","description":"Accepted plus rejected equals received.",
            "operator":"sum_equals","scope":"receipt_item","fields":["accepted","rejected"],
            "target_field":"received","related_entities":["purchase_receipt"],
            "required_evidence":["receipt lines","quality record"],"risk":"quantity mismatch"}]
        model["aggregations"] = []  # This fixture replaces the Pack invariant set.
        graph = build_business_graph(model, pack)
        invariant_nodes = [n for n in graph["nodes"] if n["kind"] == "business_invariant"]
        self.assertEqual(len(invariant_nodes), 1)
        self.assertEqual(invariant_nodes[0]["verification_status"], "declared_not_verified")
        self.assertTrue(any(e["relation"] == "constrains_entity" for e in graph["edges"]))
        model["invariants"][0]["operator"] = "execute_python"
        with self.assertRaises(BusinessModelError):
            build_business_graph(model, pack)

    def test_structured_observation_evaluates_invariant_with_evidence_links(self):
        _, pack, model = self._data()
        invariant = next(item for item in model["invariants"]
                         if item["id"] == "receipt_quantity_balance")
        evidence = [{"id":"evd_qty","asset_id":"ast_receipt","statement":"receipt quantity fixture",
                     "locator":{"path":"receipt.json","line_start":1},
                     "metadata":{"verification":{"level":"ci_check_success","runtime_observed":False}}}]
        values = {"accepted_qty":8,"rejected_qty":2,"received_qty":10}
        provenance = {field:{"evidence_id":"evd_qty",
                     "locator":{"path":"receipt.json","field":field},
                     "verification_level":"ci_check_success","runtime_observed":False}
                     for field in values}
        observations = {"schema_version":1,"observations":[{
            "id":"obs_receipt_1","asset_id":"ast_receipt",
            "invariant_id":invariant["id"],"scope_key":"receipt-item-1",
            "origin":"test","values":values,"field_provenance":provenance}]}
        requirement = {"id":"req_d03","key":"D03","version":1,"title":"材料采购",
            "acceptance_criteria":[{"id":"D03-C6","description":"区分实收、合格和拒收数量。",
                                    "required":True,"invariant_ids":[invariant["id"]]}]}
        graph = build_business_graph(model, pack, requirements=[requirement],
            assets=[{"id":"ast_receipt","title":"receipt.json","asset_type":"file","uri":"https://x/receipt.json"}],
            evidence=evidence, observations=observations)
        result = graph["invariant_evaluations"]["evaluations"][0]
        self.assertEqual(result["outcome"], "pass")
        self.assertEqual(result["verification_level"], "test_fixture")
        self.assertEqual(graph["counts"]["invariant_evaluations"], 1)
        self.assertTrue(any(edge["relation"] == "derived_from_observation"
                            and edge["evidence_ids"] == ["evd_qty"] for edge in graph["edges"]))
        self.assertEqual(graph["counts"]["invariants_passed"], 1)
        criterion = graph["criterion_evidence_matrix"][0]
        self.assertEqual(criterion["invariant_ids"], [invariant["id"]])
        self.assertEqual(criterion["invariant_status"], "computed_pass")
        self.assertEqual(criterion["invariant_evaluation_ids"], ["obs_receipt_1"])
        self.assertTrue(any(edge["relation"] == "has_invariant_evaluation"
                            and edge["status"] == "computed_not_assessed" for edge in graph["edges"]))

    def test_unknown_criterion_invariant_reference_is_rejected(self):
        _, pack, model = self._data()
        requirement = {"id":"req_d03","key":"D03","version":1,"title":"材料采购",
            "acceptance_criteria":[{"id":"D03-CX","description":"测试规则映射。",
                                    "required":True,"invariant_ids":["not_a_pack_rule"]}]}
        with self.assertRaises(BusinessModelError):
            build_business_graph(model, pack, requirements=[requirement])

    def test_invariant_rejects_non_finite_tolerance_and_duplicate_fields(self):
        _, pack, model = self._data()
        model["invariants"][0]["tolerance"] = float("nan")
        with self.assertRaises(BusinessModelError):
            validate_business_model(model, pack)
        _, pack, model = self._data()
        model["invariants"][0]["fields"] = ["accepted_qty", "accepted_qty"]
        with self.assertRaises(BusinessModelError):
            validate_business_model(model, pack)

    def test_field_aliases_must_be_unambiguous(self):
        _, pack, model = self._data()
        model["invariants"][0]["field_aliases"] = {
            "accepted_qty":["quantity"],
            "rejected_qty":[" quantity "],
            "received_qty":["received"],
        }
        with self.assertRaises(BusinessModelError):
            validate_business_model(model, pack)

    def test_scope_aliases_must_be_declared_and_unambiguous(self):
        _, pack, model = self._data()
        model["invariants"][0]["scope_fields"] = ["purchase_order_id"]
        model["invariants"][0]["scope_aliases"] = {
            "purchase_order_id":["合格数量"],
        }
        with self.assertRaises(BusinessModelError):
            validate_business_model(model, pack)

    def test_pack_aggregation_rule_is_validated_and_projected_with_evidence_links(self):
        _, pack, model = self._data()
        rule = dict(model["aggregations"][0], id="po_receipts")
        model["aggregations"] = [rule]
        with self.assertRaises(BusinessModelError):
            validate_business_model(dict(model, aggregations=[dict(rule, operation="exec")]), pack)
        evidence = []
        observations_rows = []
        for index, qty in enumerate((40, 35, 30), 1):
            asset_id = "ast_receipt_%d" % index
            evidence_id = "evd_receipt_%d" % index
            evidence.append({"id":evidence_id,"asset_id":asset_id,"statement":"receipt",
                "locator":{"path":"receipt%d.csv" % index,"row":2,"column":3},
                "metadata":{"verification":{"level":"test_fixture","runtime_observed":False}}})
            fields = {"received_qty":str(qty)}
            provenance = {"received_qty":{"evidence_id":evidence_id,
                "locator":{"path":"receipt%d.csv" % index,"row":2,"column":3},
                "verification_level":"test_fixture","runtime_observed":False}}
            scope_provenance = {}
            for scope_index, scope_field in enumerate(("purchase_order_id","purchase_order_item_id"),1):
                scope_evidence_id = evidence_id + "_scope_" + str(scope_index)
                scope_locator = {"path":"receipt%d.csv" % index,"row":2,"column":scope_index}
                evidence.append({"id":scope_evidence_id,"asset_id":asset_id,"statement":"scope",
                    "locator":scope_locator,
                    "metadata":{"verification":{"level":"test_fixture","runtime_observed":False}}})
                scope_provenance[scope_field] = {"evidence_id":scope_evidence_id,"locator":scope_locator}
            receipt_id = "PR-%d" % index
            receipt_item_id = "PR-%d-1" % index
            for scope_field, scope_value in (("receipt_id",receipt_id),("receipt_item_id",receipt_item_id)):
                scope_evidence_id = evidence_id + "_" + scope_field
                scope_locator = {"path":"receipt%d.csv" % index,"row":2,"column":10+len(scope_provenance)}
                evidence.append({"id":scope_evidence_id,"asset_id":asset_id,"statement":"identity",
                    "locator":scope_locator,
                    "metadata":{"verification":{"level":"test_fixture","runtime_observed":False}}})
                scope_provenance[scope_field] = {"evidence_id":scope_evidence_id,"locator":scope_locator}
            transaction, transaction_provenance = {}, {}
            for tx_index, (field, value) in enumerate((("document_status","1"),("is_return","0"),
                                                        ("document_type","Purchase Receipt")),20):
                tx_evidence_id = evidence_id + "_" + field
                tx_locator = {"path":"receipt%d.csv" % index,"row":2,"column":tx_index}
                evidence.append({"id":tx_evidence_id,"asset_id":asset_id,"statement":"transaction",
                    "locator":tx_locator,
                    "metadata":{"verification":{"level":"test_fixture","runtime_observed":False}}})
                transaction[field] = value
                transaction_provenance[field] = {"evidence_id":tx_evidence_id,"locator":tx_locator}
            observations_rows.append({"id":"obs_%d" % index,"asset_id":asset_id,
                "invariant_id":"receipt_quantity_balance","scope_key":"receipt-%d" % index,
                "origin":"test","values":fields,"field_provenance":provenance,
                "business_scope":{"purchase_order_id":"PO-1","purchase_order_item_id":"LINE-1",
                    "receipt_id":receipt_id,"receipt_item_id":receipt_item_id},
                "scope_provenance":scope_provenance,
                "transaction":transaction,"transaction_provenance":transaction_provenance})
        # The invariant itself requires all declared fields; use a complete, balanced observation.
        for row in observations_rows:
            qty = int(row["values"]["received_qty"])
            row["values"].update({"accepted_qty":qty,"rejected_qty":0})
            for field in ("accepted_qty","rejected_qty"):
                row["field_provenance"][field] = dict(row["field_provenance"]["received_qty"])
        assets = [{"id":"ast_receipt_%d" % index,"title":"receipt","asset_type":"file","uri":"https://x/r%d.csv" % index}
                  for index in range(1,4)]
        graph = build_business_graph(model, pack, assets=assets, evidence=evidence,
            observations={"schema_version":1,"observations":observations_rows})
        self.assertEqual(graph["counts"]["aggregation_rules"], 1)
        self.assertEqual(graph["counts"]["aggregation_groups"], 1)
        self.assertEqual(graph["counts"]["aggregation_contributions"], 3)
        agg = next(n for n in graph["nodes"] if n["kind"] == "business_aggregation")
        self.assertEqual(agg["values"]["cumulative_received_qty"], "105")
        links = [e for e in graph["edges"] if e["relation"] == "aggregated_from_evidence"]
        scope_links = [e for e in graph["edges"] if e["relation"] == "grouped_by_evidence"]
        transaction_links = [e for e in graph["edges"] if e["relation"] == "transaction_metadata_evidence"]
        self.assertEqual(len(links), 3)
        self.assertEqual(len(scope_links), 12)
        self.assertEqual(len(transaction_links), 9)
        self.assertTrue(all(e["status"] == "source_backed" for e in links + scope_links + transaction_links))

    def test_ledger_effects_are_projected_with_source_evidence_edges(self):
        _, pack, model = self._data()
        model["ledger_aggregations"] = [{
            "id":"stock_value_by_item_warehouse", "ledger_kind":"stock",
            "metric":"stock_value_delta", "output_field":"stock_value",
            "group_by":["company_id","currency","item_id","warehouse_id","quantity_uom"]}]
        asset = {"id":"ast_ledger","title":"stock-ledger.csv","asset_type":"file",
                 "uri":"https://example.test/stock-ledger.csv"}
        evidence = [{"id":"evd_ledger","asset_id":"ast_ledger","statement":"stock ledger row",
                     "locator":{"path":"stock-ledger.csv","row":2,"column":1}}]
        ledger_row = {
            "ledger_entry_id":"SLE-1","source_system":"erp","ledger_kind":"stock",
            "company_id":"CO-1","voucher_type":"Purchase Receipt","voucher_id":"PR-1",
            "voucher_item_id":"PR-ROW-1",
            "source_document_ref":{"voucher_type":"Purchase Receipt","voucher_id":"PR-1",
                                   "voucher_item_id":"PR-ROW-1"},
            "event_kind":"receipt","posting_status":"posted","currency":"USD",
            "asset_id":"ast_ledger","item_id":"ITEM-1","warehouse_id":"WH-1",
            "quantity_delta":"10","quantity_uom":"EA","stock_value_delta":"99.64",
            "evidence_id":"evd_ledger","locator":{"path":"stock-ledger.csv","row":2,"column":1}}
        graph = build_business_graph(model, pack, assets=[asset], evidence=evidence,
                                     ledger_effects=[ledger_row])
        aggregate = next(item for item in graph["nodes"]
                         if item["kind"] == "business_ledger_aggregation")
        self.assertEqual(aggregate["values"]["stock_value"], "99.64")
        self.assertEqual(aggregate["verification_status"], "computed_not_assessed")
        links = [edge for edge in graph["edges"]
                 if edge["relation"] == "ledger_aggregation_from_evidence"]
        self.assertEqual(len(links), 1)
        self.assertEqual(links[0]["evidence_ids"], ["evd_ledger"])
        self.assertEqual(graph["counts"]["ledger_aggregation_groups"], 1)
        self.assertEqual(graph["counts"]["ledger_aggregation_contributions"], 1)

    def test_gl_voucher_balance_is_projected_with_manifest_evidence(self):
        _, pack, model = self._data()
        asset = {"id":"ast_manifest","title":"voucher-manifest.json","asset_type":"file",
                 "uri":"https://example.test/voucher-manifest.json"}
        evidence = [{"id":"evd_manifest","asset_id":"ast_manifest",
                     "statement":"complete voucher extraction manifest",
                     "locator":{"path":"voucher-manifest.json","line":4}}]
        voucher_results = {
            "schema_version":1,
            "results":[{
                "scope":{"source_system":"erp","company_id":"CO-1","currency":"USD",
                         "voucher_type":"Journal Entry","voucher_id":"JV-1",
                         "accounting_period":"FY2026-P03"},
                "manifest_id":"MAN-1","status":"unbalanced","debit_total":"100",
                "credit_total":"90","difference":"10","tolerance":"0",
                "ledger_entry_ids":["GL-1","GL-2"],"evidence_ids":["evd_manifest"]}],
            "unresolved":[{"scope":{"voucher_id":"JV-2"},
                           "reason":"incomplete_voucher_extract",
                           "missing_ledger_entry_ids":["GL-3"]}]}
        graph = build_business_graph(model, pack, assets=[asset], evidence=evidence,
                                     ledger_voucher_results=voucher_results)
        voucher_node = next(item for item in graph["nodes"]
                            if item["kind"] == "business_gl_voucher")
        self.assertEqual(voucher_node["status"], "unbalanced")
        self.assertEqual(voucher_node["verification_status"], "computed_not_assessed")
        evidence_edges = [edge for edge in graph["edges"]
                          if edge["relation"] == "voucher_balance_from_evidence"]
        self.assertEqual(len(evidence_edges), 1)
        unresolved_node = next(item for item in graph["nodes"]
                               if item["kind"] == "business_gl_voucher_unresolved")
        self.assertEqual(unresolved_node["reason"], "incomplete_voucher_extract")
        self.assertEqual(graph["counts"]["ledger_vouchers_unbalanced"], 1)
        self.assertEqual(graph["counts"]["ledger_vouchers_unresolved"], 1)

    def test_inventory_gl_reconciliation_is_projected_to_both_aggregates_and_evidence(self):
        _, pack, model = self._data()
        asset = {"id":"ast_recon","title":"ledger-source.csv","asset_type":"file",
                 "uri":"https://example.test/ledger-source.csv"}
        evidence = [{"id":"evd_recon","asset_id":"ast_recon","statement":"ledger source row",
                     "locator":{"path":"ledger-source.csv","row":2,"column":1}}]
        reconciliation = {
            "schema_version":1,
            "results":[{
                "scope":{"company_id":"CO-1","currency":"USD","accounting_period":"FY2026-P03"},
                "status":"matched","stock_value":"100","general_ledger_value":"100",
                "difference":"0","tolerance":"0.01",
                "stock_aggregate_ids":["SA-1"],"gl_aggregate_ids":["GA-1"],
                "evidence_ids":["evd_recon"]}],
            "unresolved":[{"side":"stock","aggregate_id":"SA-2",
                           "reason":"missing_company_currency_or_accounting_period"}]}
        graph = build_business_graph(model, pack, assets=[asset], evidence=evidence,
            ledger_reconciliation_results=reconciliation)
        recon_node = next(item for item in graph["nodes"]
                          if item["kind"] == "business_ledger_reconciliation")
        self.assertEqual(recon_node["status"], "matched")
        self.assertEqual(recon_node["verification_status"], "computed_not_assessed")
        unresolved = next(item for item in graph["nodes"]
                          if item["kind"] == "business_ledger_reconciliation_unresolved")
        self.assertEqual(unresolved["aggregate_id"], "SA-2")
        self.assertEqual(graph["ledger_reconciliations"]["results"], reconciliation["results"])
        self.assertEqual(graph["counts"]["ledger_reconciliations_matched"], 1)
        self.assertEqual(graph["counts"]["ledger_reconciliations_unresolved"], 1)

    def test_complete_ledger_control_pipeline_result_can_be_projected(self):
        _, pack, model = self._data()
        asset = {"id":"ast_control","title":"ledger-control.json","asset_type":"file",
                 "uri":"https://example.test/ledger-control.json"}
        evidence = [{"id":"evd_control","asset_id":"ast_control",
                     "statement":"ledger control evidence",
                     "locator":{"path":"ledger-control.json","line":1}}]
        pipeline = {
            "schema_version":1,
            "validation":{"schema_version":1,"ledger_effects":[],"skipped":[],
                          "summary":{"input":0,"accepted":0,"skipped":0,
                                     "stock_entries":0,"general_ledger_entries":0,
                                     "reversal_entries":0,"missing_posting_date":0,
                                     "missing_accounting_period":0}},
            "vouchers":{"schema_version":1,"results":[{
                "scope":{"voucher_id":"JV-1","accounting_period":"FY2026-P03"},
                "manifest_id":"MAN-1","status":"balanced","debit_total":"10",
                "credit_total":"10","difference":"0","tolerance":"0",
                "ledger_entry_ids":[],"evidence_ids":["evd_control"]}],
                "unresolved":[],"summary":{"balanced":1,"unbalanced":0,"unresolved":0}},
            "aggregations":[],
            "reconciliation":{"schema_version":1,"results":[{
                "scope":{"company_id":"CO-1","currency":"USD",
                         "accounting_period":"FY2026-P03"},
                "status":"matched","stock_value":"10","general_ledger_value":"10",
                "difference":"0","tolerance":"0.01",
                "stock_aggregate_ids":[],"gl_aggregate_ids":[],
                "evidence_ids":["evd_control"]}],
                "unresolved":[],"summary":{"matched":1,"mismatched":0,"unresolved":0}},
            "summary":{},"policy":{}}
        graph = build_business_graph(model, pack, assets=[asset], evidence=evidence,
                                     ledger_control_results=pipeline)
        self.assertEqual(graph["ledger_control_pipeline"], pipeline)
        voucher = next(item for item in graph["nodes"]
                       if item["kind"] == "business_gl_voucher")
        reconciliation = next(item for item in graph["nodes"]
                               if item["kind"] == "business_ledger_reconciliation")
        self.assertEqual(voucher["verification_status"], "computed_not_assessed")
        self.assertEqual(reconciliation["verification_status"], "computed_not_assessed")

    def test_pipeline_result_cannot_be_mixed_with_individual_ledger_inputs(self):
        _, pack, model = self._data()
        with self.assertRaises(BusinessModelError):
            build_business_graph(model, pack, ledger_effects=[],
                                 ledger_control_results={"schema_version":1,
                                     "aggregations":[],"vouchers":{},
                                     "reconciliation":{}})

    def test_projection_is_deterministic(self):
        _, pack, model = self._data()
        assets = [{"id":"ast_file_1","title":"x","asset_type":"file","uri":"https://x"}]
        evidence = [{"id":"evd_1","asset_id":"ast_file_1","statement":"Purchase Order",
                     "locator":{"path":"x","line_start":1},"verification_status":"unverified"}]
        self.assertEqual(build_business_graph(model, pack, assets=assets, evidence=evidence),
                         build_business_graph(model, pack, assets=assets, evidence=evidence))

if __name__ == "__main__":
    unittest.main()
