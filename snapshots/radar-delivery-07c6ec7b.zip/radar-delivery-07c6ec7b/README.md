# radar — review & repair delivery bundle

**Bundle ID:** `radar-delivery-07c6ec7b`
**Prepared:** 2026-11-22
**Source commit:** `07c6ec7b97569e8a329d9f932f7e65113193a677`
**Source branch at snapshot time:** `feat/requirement-driven-discovery`
**Review baseline:** `main` @ `40c0528141b88c0a80ed25015b982ae44a8f8992`

This bundle contains the exact source snapshot, the two review reports, the
repair handoff, and the deliberately failing contract-test skeleton.

## Contents

```text
radar-delivery-07c6ec7b/
├── README.md                         # this file
├── MANIFEST.sha256                   # checksums for every payload file
├── source/                           # exact tree of 07c6ec7b (151 files)
├── review-artifacts/
│   ├── docs/reviews/
│   │   ├── 2026-11-22-main-review.md
│   │   ├── 2026-11-22-branch-review.md
│   │   └── 2026-11-22-branch-fix-handoff.md
│   └── tests/review_p0/
│       ├── README.md
│       ├── run.py
│       └── test_branch_p0_contracts.py
└── archives/
    ├── radar-07c6ec7b...tar.gz
    ├── radar-07c6ec7b...zip
    └── SHA256SUMS
```

`review-artifacts/` mirrors the repository layout (`docs/reviews/`,
`tests/review_p0/`) so it can be copied into a checkout without rewriting paths.

## What each document is

| File | Purpose |
|---|---|
| `2026-11-22-main-review.md` | Review of `main@40c0528`: 4 P0 issues, 10 P1 issues, doc drift, CI governance, recommended order |
| `2026-11-22-branch-review.md` | Review of `07c6ec7b` against main: scope, merge verdict, new risks, P0 evidence matrix, reverse-test matrix |
| `2026-11-22-branch-fix-handoff.md` | Executable repair plan: PR-0 → PR-6, file scope, test mapping, Definition of Done, constraints, stop conditions |
| `tests/review_p0/` | 13 review-only contract tests; expected to fail on this source snapshot |

The handoff is the entry point for whoever performs the fixes. The two review
reports are the evidence behind it.

## Quick verification

```bash
cd source
python3 -m unittest discover -s tests
# Ran 259 tests ... OK

cd ..
python3 review-artifacts/tests/review_p0/run.py --branch-root "$PWD/source"
# Ran 13 tests ... FAILED (failures=13)
```

The 13 failures are intentional: they encode the target behavior described in
the handoff. They must not be "fixed" by weakening the tests.

Verify file integrity:

```bash
sha256sum -c MANIFEST.sha256
tar -tzf archives/radar-07c6ec7b97569e8a329d9f932f7e65113193a677.tar.gz | head
```

## How to use this bundle

1. Read `review-artifacts/docs/reviews/2026-11-22-branch-fix-handoff.md`.
2. Create the repair branch from `main@40c0528`, **not** from the source snapshot.
3. Copy the review artifacts into the checkout if needed:

   ```bash
   cp -a review-artifacts/docs/reviews/.  <checkout>/docs/reviews/
   cp -a review-artifacts/tests/review_p0/. <checkout>/tests/review_p0/
   ```

4. Use `source/` only as the read-only reference implementation for the broken
   behavior; do not merge it into main.
5. Run the review suite against the snapshot to reproduce the 13 red tests,
   then follow PR-0 → PR-6 and move each test into the normal `tests/` suite as
   its fix lands.

## Important constraints

- Do **not** merge `feat/requirement-driven-discovery` as a whole.
- Do **not** modify `docs/reviews/` when fixing code.
- Do **not** weaken or delete the contract tests.
- Do **not** add third-party dependencies.
- Do **not** drop main capabilities (`parse` CLI, capability registry,
  `xml_safety.py`, `requirements-*.txt`, optional parser CI jobs).
- Every PR starts with a failing test, then the minimal fix.
- The fixer does not self-approve or self-merge.

## Integrity notes

- `source/` was extracted from GitHub's codeload archive of the exact commit.
- Source tree: 151 files, about 1.6 MB; no `.git`, no `__pycache__`, no `.pyc`.
- The tar.gz and zip in `archives/` were extracted and compared file-by-file:
  identical trees.
- `MANIFEST.sha256` covers all files except itself.
- Archive checksums are recorded both in `archives/SHA256SUMS` and in
  `MANIFEST.sha256`.
